# Solid Properties Website
This is the official Solid Properties website — built with HTML, CSS, and JS.

## Hosting Instructions (GitHub Pages)
1. Go to https://github.com/
2. Create a new public repository named `solidproperties-website`
3. Upload all these files and folders.
4. In Settings > Pages, choose Branch: `main` / Folder: `/ (root)`
5. Click Save.
Your website will be live at:
`https://<yourusername>.github.io/solidproperties-website/`

Contact: 0728 865 833 | TikTok: @solidproperties24
